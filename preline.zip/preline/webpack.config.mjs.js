const path = require('path');
const fs = require('fs');
const TerserPlugin = require('terser-webpack-plugin');

const pluginsDir = path.resolve(__dirname, 'src/plugins');
const helperEntries = {
	'helper-shared': './src/helpers/shared/index.ts',
	'helper-apexcharts': './src/helpers/apexcharts/index.ts',
	'helper-clipboard': './src/helpers/clipboard/index.ts',
	utils: './src/utils/index.ts',
};
const excludedPluginEntries = new Set(['accessibility-manager', 'base-plugin']);

const pluginEntries = fs
	.readdirSync(pluginsDir)
	.filter((pluginName) => {
		if (excludedPluginEntries.has(pluginName)) return false;

		const pluginDir = path.join(pluginsDir, pluginName);
		if (!fs.lstatSync(pluginDir).isDirectory()) return false;

		return (
			fs.existsSync(path.join(pluginDir, 'auto.ts')) ||
			fs.existsSync(path.join(pluginDir, 'core.ts'))
		);
	})
	.reduce((acc, pluginName) => {
		const pluginDir = path.join(pluginsDir, pluginName);

		if (fs.existsSync(path.join(pluginDir, 'auto.ts')))
			acc[pluginName] = `./src/plugins/${pluginName}/auto.ts`;

		if (fs.existsSync(path.join(pluginDir, 'core.ts')))
			acc[`${pluginName}-non-auto`] = `./src/plugins/${pluginName}/core.ts`;

		return acc;
	}, {});

module.exports = {
	mode: 'production',
	stats: 'minimal',
	entry: {
		index: './src/auto/index.ts',
		'non-auto': './src/index.ts',
		...pluginEntries,
		...helperEntries,
	},
	module: {
		rules: [
			{ test: /\.ts?$/, enforce: 'pre', use: ['source-map-loader'] },
			{
				test: /\.ts?$/,
				use: [
					{
						loader: 'ts-loader',
						options: {
							configFile: 'tsconfig.mjs.json',
						},
					},
				],
				exclude: /node_modules/,
			},
		],
	},
	experiments: {
		outputModule: true,
	},
	resolve: {
		extensions: ['.ts', '.js'],
		alias: {
			VanillaCalendarPro: 'vanilla-calendar-pro',
		},
	},
	output: {
		path: path.resolve(__dirname, 'dist'),
		filename: '[name].mjs',
		libraryTarget: 'module',
	},
	externals: {
		jquery: 'jQuery',
		lodash: '_',
		apexcharts: 'ApexCharts',
		'datatable.net-dt': 'DataTable',
		dropzone: 'Dropzone',
		clipboard: 'ClipboardJS',
		noUiSlider: 'noUiSlider',
		VanillaCalendarPro: 'VanillaCalendarPro',
	},
	optimization: {
		moduleIds: 'deterministic',
		minimize: true,
		minimizer: [
			new TerserPlugin({
				extractComments: false,
				terserOptions: {
					format: {
						comments: /^!|@preserve|@license|@cc_on/i,
					},
				},
			}),
		],
	},
};
