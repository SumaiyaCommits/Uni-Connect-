#!/usr/bin/env pwsh
$basedir=Split-Path $MyInvocation.MyCommand.Definition -Parent

$exe=""
if ($PSVersionTable.PSVersion -lt "6.0" -or $IsWindows) {
  # Fix case when both the Windows and Linux builds of Node
  # are installed in the same directory
  $exe=".exe"
}
# Support pipeline input
if ($MyInvocation.ExpectingInput) {
  $input | & "$basedir/../preline/skills/theme-generator/scripts/generate-theme.js"   $args
} else {
  & "$basedir/../preline/skills/theme-generator/scripts/generate-theme.js"   $args
}
exit $LASTEXITCODE
