import { NextResponse } from "next/server";
import { PORTAL_PATH, ROLE_COOKIE, findAccount } from "../../../lib/auth";

export async function POST(request: Request) {
    let body: { email?: unknown; password?: unknown } = {};
    try {
        body = await request.json();
    } catch {
        // fall through: empty body is treated as invalid credentials
    }

    const email = typeof body.email === "string" ? body.email : "";
    const password = typeof body.password === "string" ? body.password : "";
    const account = findAccount(email, password);

    if (!account) {
        return NextResponse.json(
            { error: "Incorrect email or password." },
            { status: 401 }
        );
    }

    const response = NextResponse.json({
        role: account.role,
        redirect: PORTAL_PATH[account.role],
    });

    response.cookies.set(ROLE_COOKIE, account.role, {
        httpOnly: true,
        sameSite: "lax",
        secure: process.env.NODE_ENV === "production",
        path: "/",
        maxAge: 60 * 60 * 8, // 8 hours
    });

    return response;
}