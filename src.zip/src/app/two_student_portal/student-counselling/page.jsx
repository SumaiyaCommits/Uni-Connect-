
"use client";

import { useState } from "react";
import "./student-counselling.css";

const schedules = {
  "2026-10-19": {
    name: "Dr. Samira Ahmed",
    initials: "SA",
    specialty: "Academic planning and wellbeing",
    slots: [
      ["09:00 AM", "09:30 AM", true],
      ["10:00 AM", "10:30 AM", false],
      ["11:00 AM", "11:30 AM", true],
      ["01:30 PM", "02:00 PM", true],
      ["03:00 PM", "03:30 PM", false],
    ],
  },
  "2026-10-20": {
    name: "Mr. Farhan Kabir",
    initials: "FK",
    specialty: "Stress management and study skills",
    slots: [
      ["09:30 AM", "10:00 AM", true],
      ["10:30 AM", "11:00 AM", true],
      ["12:00 PM", "12:30 PM", false],
      ["02:00 PM", "02:30 PM", true],
      ["03:30 PM", "04:00 PM", false],
    ],
  },
  "2026-10-21": {
    name: "Dr. Samira Ahmed",
    initials: "SA",
    specialty: "Academic planning and wellbeing",
    slots: [
      ["09:00 AM", "09:30 AM", false],
      ["10:00 AM", "10:30 AM", true],
      ["11:30 AM", "12:00 PM", true],
      ["01:00 PM", "01:30 PM", false],
      ["02:30 PM", "03:00 PM", true],
    ],
  },
  "2026-10-22": {
    name: "Ms. Nadia Rahman",
    initials: "NR",
    specialty: "Personal development and adjustment",
    slots: [
      ["09:00 AM", "09:30 AM", true],
      ["10:30 AM", "11:00 AM", false],
      ["11:30 AM", "12:00 PM", true],
      ["01:30 PM", "02:00 PM", true],
      ["03:00 PM", "03:30 PM", true],
    ],
  },
  "2026-10-23": {
    name: "Mr. Farhan Kabir",
    initials: "FK",
    specialty: "Stress management and study skills",
    slots: [
      ["09:30 AM", "10:00 AM", false],
      ["10:30 AM", "11:00 AM", true],
      ["12:00 PM", "12:30 PM", true],
      ["02:00 PM", "02:30 PM", false],
      ["03:30 PM", "04:00 PM", true],
    ],
  },
};

const dates = Object.keys(schedules);

function formatDate(value) {
  return new Date(value + "T12:00:00").toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
  });
}

export default function StudentCounselling() {
  const [date, setDate] = useState(dates[0]);
  const [booked, setBooked] = useState([]);
  const [pending, setPending] = useState(null);
  const [notice, setNotice] = useState("");

  const schedule = schedules[date];

  function showNotice(message) {
    setNotice(message);
  }

  function confirmBooking() {
    if (!pending) return;

    const key = `${pending.date}|${pending.index}`;

    if (booked.includes(key)) {
      setPending(null);
      showNotice("That slot has already been booked.");
      return;
    }

    setBooked((previous) => [...previous, key]);
    setPending(null);
    showNotice(
      `Session booked with ${schedules[pending.date].name} for ${pending.slot[0]} on ${formatDate(pending.date)}.`
    );
  }

  const availableCount = schedule.slots.filter(
    (slot, index) => slot[2] && !booked.includes(`${date}|${index}`)
  ).length;

  return (
    <main className="counselling-page">
      <section className="counselling-intro">
        <span className="counselling-eyebrow">Student portal</span>
        <h1>Student Counselling</h1>
        <p>
          Choose a date to see counsellor availability and book a time that
          works for you.
        </p>
      </section>

      <section className="counselling-panel">
        <div className="counselling-panel-heading">
          <div className="counselling-icon">▦</div>
          <div>
            <h2>Choose a counselling date</h2>
            <p>Select a date to view the available counsellor and session times.</p>
          </div>
        </div>

        <div className="counselling-date-field">
          <label htmlFor="counselling-date">Counselling date</label>
          <select
            id="counselling-date"
            value={date}
            onChange={(event) => setDate(event.target.value)}
          >
            {dates.map((item) => (
              <option key={item} value={item}>
                {formatDate(item)}
              </option>
            ))}
          </select>
        </div>

        <p className="counselling-hint">
          Sample schedule for this prototype. Select another date to view
          another counsellor or set of available times.
        </p>
      </section>

      <section className="counselling-panel">
        <div className="counsellor-head">
          <div className="counselling-avatar">{schedule.initials}</div>
          <div className="counsellor-info">
            <h2>{schedule.name}</h2>
            <p>Student Counsellor · {schedule.specialty}</p>
          </div>
          <span className="counselling-availability">
            {availableCount} slots available
          </span>
        </div>

        <div className="counselling-slots-heading">
          <h3>Session time slots</h3>
          <span>{formatDate(date)}</span>
        </div>

        <div className="counselling-slot-list">
          {schedule.slots.map((slot, index) => {
            const key = `${date}|${index}`;
            const isBooked = booked.includes(key);
            const available = slot[2] && !isBooked;

            return (
              <div className="counselling-slot-row" key={key}>
                <div className="counselling-slot-time">
                  <div className="counselling-time-icon">◷</div>
                  <div>
                    <strong>{slot[0]} – {slot[1]}</strong>
                    <span>30-minute counselling session</span>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={!available}
                  className={
                    available
                      ? "counselling-book-btn"
                      : "counselling-unavailable-btn"
                  }
                  onClick={() => setPending({ date, index, slot })}
                >
                  {available
                    ? "Book Now"
                    : isBooked
                      ? "Already booked"
                      : "Slot not available"}
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {notice && (
        <div className="counselling-notice" role="status">
          <span>{notice}</span>
          <button type="button" onClick={() => setNotice("")}>
            ×
          </button>
        </div>
      )}

      {pending && (
        <div
          className="counselling-modal-backdrop"
          onClick={() => setPending(null)}
        >
          <section
            className="counselling-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="counselling-modal-title"
            onClick={(event) => event.stopPropagation()}
          >
            <h2 id="counselling-modal-title">Confirm counselling session</h2>
            <p>
              Book a session with {schedules[pending.date].name} on{" "}
              {formatDate(pending.date)} from {pending.slot[0]} to{" "}
              {pending.slot[1]}?
            </p>
            <p className="counselling-modal-hint">
              This prototype reserves the slot only while the page is open.
              It is not saved to the database.
            </p>
            <div className="counselling-modal-actions">
              <button
                className="counselling-cancel-btn"
                onClick={() => setPending(null)}
              >
                Cancel
              </button>
              <button
                className="counselling-confirm-btn"
                onClick={confirmBooking}
              >
                Confirm booking
              </button>
            </div>
          </section>
        </div>
      )}
    </main>
  );
}
