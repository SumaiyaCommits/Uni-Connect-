// Prototype authentication helpers (server-side only).
// Do NOT import this file from a "use client" component: it holds the test
// passwords. Replace ACCOUNTS with a real database lookup when a backend exists.

export type Role = "student" | "faculty" | "counsellor";

export const ROLE_COOKIE = "uc_role";

export const PORTAL_PATH: Record<Role, string> = {
    student: "/two_student_portal",
    faculty: "/three_faculty_portal",
    counsellor: "/four_counsellor_portal",
};

const ACCOUNTS: { email: string; password: string; role: Role }[] = [
    { email: "student@uni.edu", password: "student123", role: "student" },
    { email: "faculty@uni.edu", password: "faculty123", role: "faculty" },
    { email: "counsellor@uni.edu", password: "counsellor123", role: "counsellor" },
];

export function findAccount(email: string, password: string) {
    const e = email.trim().toLowerCase();
    return ACCOUNTS.find((a) => a.email === e && a.password === password);
}

export function isRole(value: unknown): value is Role {
    return value === "student" || value === "faculty" || value === "counsellor";
}