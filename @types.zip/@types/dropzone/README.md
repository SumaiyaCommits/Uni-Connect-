# Installation
> `npm install --save @types/dropzone`

# Summary
This package contains type definitions for dropzone (http://www.dropzonejs.com/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/dropzone.

### Additional Details
 * Last updated: Tue, 19 Nov 2024 18:38:08 GMT
 * Dependencies: [@types/jquery](https://npmjs.com/package/@types/jquery)

# Credits
These definitions were written by [Natan Vivo](https://github.com/nvivo), [Andy Hawkins](https://github.com/a904guy/,http://a904guy.com/,http://www.bmbsqd.com), [Vasya Aksyonov](https://github.com/outring), [Simon Huber](https://github.com/renuo), [Sebastiaan de Rooij](https://github.com/Hikariii), [Ted Bicknell](https://github.com/tedbcsgpro), [PikachuEXE](https://github.com/PikachuEXE), [Arne Deruwe](https://github.com/arnederuwe), [Chris Macklin](https://github.com/macklin-10x), and [Michał Lipiński](https://github.com/falsyvalues).
